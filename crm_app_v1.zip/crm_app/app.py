import streamlit as st
import sqlite3
import pandas as pd
from openai import OpenAI
import os
import datetime

# --- CONFIGURATION ---
st.set_page_config(page_title="AutoSales AI CRM", page_icon="🚗", layout="wide")
DB_FILE = 'crm.db'

# Initialize OpenAI Client
# Note: Ensure OPENAI_API_KEY is set in environment
client = OpenAI()

# --- DATABASE FUNCTIONS ---
def get_connection():
    return sqlite3.connect(DB_FILE)

def get_leads():
    conn = get_connection()
    df = pd.read_sql("SELECT * FROM leads ORDER BY created_at DESC", conn)
    conn.close()
    return df

def add_lead(name, phone, source, vehicle, budget):
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT INTO leads (name, phone, source, status, vehicle_interest, budget) VALUES (?, ?, ?, ?, ?, ?)",
              (name, phone, source, 'New', vehicle, budget))
    conn.commit()
    conn.close()

def update_status(lead_id, new_status):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE leads SET status = ? WHERE id = ?", (new_status, lead_id))
    conn.commit()
    conn.close()

def log_interaction(lead_id, recording_name, transcript, ai_summary, sentiment, insights):
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        INSERT INTO interactions (lead_id, recording_name, transcript, ai_summary, sentiment, key_insights)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (lead_id, recording_name, transcript, ai_summary, sentiment, insights))
    conn.commit()
    conn.close()

def get_lead_interactions(lead_id):
    conn = get_connection()
    df = pd.read_sql("SELECT * FROM interactions WHERE lead_id = ? ORDER BY timestamp DESC", conn, params=(lead_id,))
    conn.close()
    return df

# --- AI FUNCTIONS ---
def transcribe_audio(audio_file):
    # Uses OpenAI Whisper model
    transcript = client.audio.transcriptions.create(
        model="whisper-1", 
        file=audio_file
    )
    return transcript.text

def analyze_call(transcript):
    # Uses GPT-4o to analyze sales call
    prompt = f"""
    You are an expert Automotive Sales Manager AI. Analyze this call transcript between a Sales Exec and a Customer.
    
    TRANSCRIPT:
    "{transcript}"
    
    Extract and structure the following:
    1. Sentiment: (Hot / Warm / Cold)
    2. Vehicle Interest: (Model, Year, Color mentioned)
    3. Budget/Financing: (Mentioned budget, cash vs finance)
    4. Key Objections: (Price, Trade-in value, Competitor offers)
    5. Next Action: (What should the sales exec do next?)
    6. Summary: (2 sentence summary)
    
    Format as JSON-like key-value pairs.
    """
    
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "system", "content": "You are a helpful CRM assistant."},
                  {"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content

# --- UI LAYOUT ---

st.title("🚗 AutoSales AI CRM")
st.markdown("### Intelligent Lead Management & Call Analysis")

# Sidebar - Navigation
menu = st.sidebar.radio("Menu", ["Dashboard", "Add New Lead", "Lead Details & AI Analysis"])

if menu == "Dashboard":
    st.subheader("📊 Sales Pipeline")
    
    # Metrics
    leads = get_leads()
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Leads", len(leads))
    col2.metric("Hot Leads (Negotiation)", len(leads[leads['status']=='Negotiation']))
    col3.metric("New Social Media Leads", len(leads[leads['source']=='Social Media']))
    
    st.divider()
    
    # Lead Table
    st.dataframe(leads, use_container_width=True)

elif menu == "Add New Lead":
    st.subheader("➕ Add New Lead")
    with st.form("new_lead_form"):
        col1, col2 = st.columns(2)
        name = col1.text_input("Customer Name")
        phone = col2.text_input("Phone Number")
        source = col1.selectbox("Lead Source", ["Social Media", "Walk-in", "Referral", "Website"])
        vehicle = col2.text_input("Vehicle of Interest (e.g. Nissan Patrol)")
        budget = st.text_input("Estimated Budget (AED)")
        
        submitted = st.form_submit_button("Create Lead")
        if submitted:
            add_lead(name, phone, source, vehicle, budget)
            st.success(f"Lead '{name}' created successfully!")

elif menu == "Lead Details & AI Analysis":
    st.subheader("🕵️ Lead Intelligence")
    
    # Lead Selector
    leads = get_leads()
    lead_names = [f"{row['id']} - {row['name']}" for index, row in leads.iterrows()]
    selected_lead_str = st.selectbox("Select Lead to View/Update", lead_names)
    
    if selected_lead_str:
        lead_id = int(selected_lead_str.split(" - ")[0])
        lead_data = leads[leads['id'] == lead_id].iloc[0]
        
        # Display Lead Info
        col1, col2, col3 = st.columns(3)
        col1.info(f"**Name:** {lead_data['name']}")
        col2.info(f"**Status:** {lead_data['status']}")
        col3.info(f"**Interest:** {lead_data['vehicle_interest']}")
        
        # Status Updater
        new_status = st.selectbox("Update Status", ["New", "Contacted", "Test Drive", "Negotiation", "Won", "Lost"], index=["New", "Contacted", "Test Drive", "Negotiation", "Won", "Lost"].index(lead_data['status']) if lead_data['status'] in ["New", "Contacted", "Test Drive", "Negotiation", "Won", "Lost"] else 0)
        if st.button("Update Status"):
            update_status(lead_id, new_status)
            st.success("Status Updated!")
            st.rerun()
            
        st.divider()
        
        # --- AI CALL ANALYSIS SECTION ---
        st.markdown("### 🎙️ AI Call Analysis")
        st.markdown("Upload a call recording to extract insights automatically.")
        
        audio_file = st.file_uploader("Upload Call Recording (MP3/WAV)", type=['mp3', 'wav', 'm4a'])
        
        if audio_file:
            st.audio(audio_file)
            
            if st.button("🚀 Analyze Recording"):
                with st.spinner("Transcribing audio (Whisper)..."):
                    # 1. Transcribe
                    transcript = transcribe_audio(audio_file)
                    st.success("Transcription Complete!")
                    with st.expander("View Full Transcript"):
                        st.write(transcript)
                        
                with st.spinner("Analyzing with AI (GPT-4o)..."):
                    # 2. Analyze
                    analysis = analyze_call(transcript)
                    
                    # 3. Log to DB
                    log_interaction(lead_id, audio_file.name, transcript, analysis, "Analyzed", analysis)
                    
                    st.success("Analysis Complete!")
                    st.markdown("#### 🧠 AI Insights:")
                    st.info(analysis)
                    
        # History
        st.divider()
        st.markdown("### 📜 Interaction History")
        history = get_lead_interactions(lead_id)
        if not history.empty:
            for index, row in history.iterrows():
                with st.expander(f"📞 Call Analysis - {row['timestamp']}"):
                    st.markdown(f"**AI Insights:**\n{row['key_insights']}")
                    st.markdown(f"**Transcript:**\n{row['transcript']}")
        else:
            st.caption("No call history yet.")


import sqlite3

def init_db():
    conn = sqlite3.connect('crm.db')
    c = conn.cursor()
    
    # Create Leads Table
    c.execute('''
        CREATE TABLE IF NOT EXISTS leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            source TEXT DEFAULT 'Social Media',
            status TEXT DEFAULT 'New',
            vehicle_interest TEXT,
            budget TEXT,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create Interactions/Call Logs Table
    c.execute('''
        CREATE TABLE IF NOT EXISTS interactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lead_id INTEGER,
            recording_name TEXT,
            transcript TEXT,
            ai_summary TEXT,
            sentiment TEXT,
            key_insights TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (lead_id) REFERENCES leads (id)
        )
    ''')
    
    # Seed some dummy data
    c.execute("INSERT OR IGNORE INTO leads (id, name, phone, source, status, vehicle_interest) VALUES (1, 'Ahmed Al-Mansoori', '+971501234567', 'Instagram', 'Negotiation', 'Nissan Patrol')")
    c.execute("INSERT OR IGNORE INTO leads (id, name, phone, source, status, vehicle_interest) VALUES (2, 'Sarah Jones', '+971559876543', 'Facebook', 'New', 'Toyota RAV4')")
    
    conn.commit()
    conn.close()
    print("Database initialized successfully.")

if __name__ == '__main__':
    init_db()
